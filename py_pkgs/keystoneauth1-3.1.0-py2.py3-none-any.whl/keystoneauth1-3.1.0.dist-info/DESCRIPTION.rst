========================
Team and repository tags
========================

.. image:: https://governance.openstack.org/badges/keystoneauth.svg
    :target: https://governance.openstack.org/reference/tags/index.html

.. Change things from this point on

============
keystoneauth
============

.. image:: https://img.shields.io/pypi/v/keystoneauth1.svg
    :target: https://pypi.python.org/pypi/keystoneauth1/
    :alt: Latest Version

.. image:: https://img.shields.io/pypi/dm/keystoneauth1.svg
    :target: https://pypi.python.org/pypi/keystoneauth1/
    :alt: Downloads

This package contains tools for authenticating to an OpenStack-based cloud.
These tools include:

* Authentication plugins (password, token, and federation based)
* Discovery mechanisms to determine API version support
* A session that is used to maintain client settings across requests (based on
  the requests Python library)

Further information:

* Free software: Apache license
* Documentation: https://docs.openstack.org/keystoneauth/latest/
* Source: https://git.openstack.org/cgit/openstack/keystoneauth
* Bugs: https://bugs.launchpad.net/keystoneauth



