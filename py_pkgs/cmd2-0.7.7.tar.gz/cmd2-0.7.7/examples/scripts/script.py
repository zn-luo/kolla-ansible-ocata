#!/usr/bin/env python
# coding=utf-8
"""
Trivial example of a Python script which can be run inside a cmd2 application.
"""
print("This is a python script running ...")

